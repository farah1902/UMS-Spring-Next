package com.saadfarah.user_mngt_system_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserMngtSystemBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMngtSystemBackApplication.class, args);
	}

}
